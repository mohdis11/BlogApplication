// Simulated storage (in-memory)
let blogPosts = []; // Stores blog posts
let currentUser = { username: 'Guest', email: '' }; // Simulated current user

// Function to render blog posts in the list
function renderBlogList() {
    const blogList = document.getElementById('posts-container');
    blogList.innerHTML = ''; // Clear the list

    blogPosts.forEach((post, index) => {
        const postItem = document.createElement('div');
        postItem.className = 'post-item';
        postItem.textContent = post.title; // Display the post title
        postItem.onclick = () => viewPost(index); // Set click event to view post
        blogList.appendChild(postItem);
    });
}

// Function to display an individual post
function viewPost(index) {
    const postPage = document.getElementById('post-page');
    const blogListSection = document.getElementById('blog-list');
    const postContent = document.getElementById('post-content');

    // Hide the blog list and show the individual post page
    blogListSection.classList.remove('active');
    postPage.classList.add('active');

    const post = blogPosts[index];
    postContent.innerHTML = `<h2>${post.title}</h2>${marked(post.content)}`; // Convert Markdown to HTML using marked.js
    renderComments(index);
}

// Function to render comments for a post
function renderComments(index) {
    const commentsContainer = document.getElementById('comments-container');
    commentsContainer.innerHTML = ''; // Clear comments section

    blogPosts[index].comments.forEach(comment => {
        const commentItem = document.createElement('div');
        commentItem.className = 'comment-item';
        commentItem.textContent = comment;
        commentsContainer.appendChild(commentItem);
    });
}

// Function to handle the publish action
document.getElementById('publish-btn').addEventListener('click', async () => {
    const editor = document.getElementById('markdown-editor');
    const content = editor.value.trim();
    const title = content.split('\n')[0] || 'Untitled';
    const tags = document.getElementById('post-tags').value;
    const category = document.getElementById('post-category').value;

    if (content) {
        // Simulate a call to the server
        const newPost = { title, content, tags, category, comments: [] };
        blogPosts.push(newPost); // Add the post to the in-memory storage
        editor.value = ''; // Clear the editor
        document.getElementById('post-tags').value = '';
        document.getElementById('post-category').value = '';
        renderBlogList(); // Refresh the list
        navigateTo('blog-list'); // Navigate back to the blog list
    }
});

// Function to handle adding comments
document.getElementById('add-comment-btn').addEventListener('click', () => {
    const commentInput = document.getElementById('comment-input');
    const comment = commentInput.value.trim();
    if (comment) {
        const postIndex = blogPosts.findIndex(post => post.title === document.querySelector('#post-content h2').textContent);
        if (postIndex > -1) {
            blogPosts[postIndex].comments.push(comment);
            commentInput.value = '';
            renderComments(postIndex);
        }
    }
});

// Function to handle user profile update
document.getElementById('update-profile-btn').addEventListener('click', () => {
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    if (username && email) {
        currentUser.username = username;
        currentUser.email = email;
        alert('Profile updated successfully!');
        navigateTo('blog-list'); // Navigate back to the blog list
    }
});

// Navigation handlers
document.getElementById('new-post-btn').addEventListener('click', () => {
    navigateTo('post-editor');
});

document.getElementById('back-btn').addEventListener('click', () => {
    navigateTo('blog-list');
});

document.getElementById('back-to-list-btn').addEventListener('click', () => {
    navigateTo('blog-list');
});

document.getElementById('user-profile-btn').addEventListener('click', () => {
    navigateTo('user-profile');
    document.getElementById('username').value = currentUser.username;
    document.getElementById('email').value = currentUser.email;
});

// Function to handle navigation between sections
function navigateTo(sectionId) {
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

// Initialize the app by rendering the blog list
renderBlogList();
