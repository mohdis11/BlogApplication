package com.ismail.blog.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Primary key

    @Lob
    @Column(nullable = false,name = "content")
    private String content;  // Content of the comment

    @ManyToOne
    @JoinColumn(name = "post_id", nullable = false)
    private Post post;  // The post that this comment is associated with

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;  // The user who wrote the comment

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;  // Timestamp when the comment was created

    // Constructors
    public Comment() {
        this.createdAt = LocalDateTime.now();  // Set created time by default
    }

    public Comment(String content, Post post, User user) {
        this.content = content;
        this.post = post;
        this.user = user;
        this.createdAt = LocalDateTime.now();  // Set created time by default
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    // Override toString method for debugging
    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", post=" + (post != null ? post.getId() : null) +
                ", user=" + (user != null ? user.getUsername() : null) +
                ", createdAt=" + createdAt +
                '}';
    }
}
